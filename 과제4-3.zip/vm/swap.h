#ifndef VM_SWAP_H
#define VM_SWAP_H

#include "vm/page.h"

void swap_init (void);
bool swap_in (int index, uint8_t *frame);
bool swap_out (uint8_t *frame, struct sup_page_table_entry *spte);
void read_from_disk (uint8_t *frame, int index);
void write_to_disk (uint8_t *frame, int index);

#endif /* vm/swap.h */
