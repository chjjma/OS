#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include "filesys/filesys.h"
#include "filesys/file.h"

void syscall_init (void);
void close(int fd);
struct file *get_file(int fd);

#endif /* userprog/syscall.h */
