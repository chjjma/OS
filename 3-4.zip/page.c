#include "vm/page.h"
#include "vm/swap.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "threads/vaddr.h"
#include "userprog/syscall.h"
#include "filesys/filesys.h"
#include <string.h>
#include <list.h>
#include "filesys/file.h"
#include "threads/synch.h"
#include "threads/thread.h"

/*
 * Initialize supplementary page table for process
 */
void page_init (struct thread *t){
	list_init(&t->spt);
	lock_init(&t->sptlock);
}

//return true if page have to use swap disk
bool use_swap(struct sup_page_table_entry *spte){
	if (spte->file_inf == NULL){
		return true;
	}
	if (spte_get_dirty(spte) && spte->file_inf->fd == -1){
		return true;
	}
	return false;
}

bool spte_read(struct sup_page_table_entry *spte, uint8_t *frame){
	if (spte->swap_index != -1){
		swap_in(spte->swap_index, frame);
		spte->swap_index = -1;
		return true;
	}
	if (spte->file_inf != NULL){
		struct file_inf *fi = spte->file_inf;
		struct file *file;
		if (fi->fd != -1){
			file = get_file(fi->fd);
		}
		else{
			file = spte->owner->executable;
		}
		int old_ofs = file_tell(file);
	    file_seek (file, fi->ofs);
		/* Load this page. */
		if (file_read (file, frame, fi->read_bytes) != (int) fi->read_bytes){
			file_seek (file, old_ofs);
			return false;
		}
		memset (frame + fi->read_bytes, 0, fi->zero_bytes);
		file_seek(file, old_ofs);
		return true;
	}
	return false;
}

bool spte_write_file(struct sup_page_table_entry *spte, uint8_t *frame){
	if (spte->file_inf == NULL){
		return false;
	}
	if (!spte_get_dirty(spte)){
		return false;
	}
	struct file_inf *fi = spte->file_inf;
	struct file *file;
	if (fi->fd == -1){
		return false;
	}
	file = get_file(fi->fd);
	int old_ofs = file_tell(file);
    file_seek (file, fi->ofs);
	/* Load this page. */
	if (file_write (file, frame, fi->read_bytes) != (int) fi->read_bytes)
	{
		file_seek (file, old_ofs);
		return false;
	}
	file_seek (file, old_ofs);
	return true;
}

bool spte_save_data(struct sup_page_table_entry *spte, uint8_t *frame){
	if (use_swap(spte)){
		swap_out(frame, spte);
		return true;
	}
	return spte_write_file(spte, frame);
}

bool set_frame(struct sup_page_table_entry *spte, uint8_t *frame){
	if (spte== NULL) return false;
	if (frame== NULL) return false;
	struct thread *t = spte->owner;
	if (pagedir_get_page (t->pagedir, spte->user_vaddr) != NULL) {
      	return false;
    }
    if (!pagedir_set_page (t->pagedir, spte->user_vaddr, frame, spte->writable)){
    	return false;
	}
	allocate_frame(frame, spte);
    return true;
}

struct file_inf *allocate_fileinf(int fd, off_t ofs, uint32_t read_bytes, uint32_t zero_bytes, bool writable, int mapid){
	struct file_inf *fi = malloc(sizeof(struct file_inf));
	if (fi == NULL){
		return NULL;
	}
	// header file not included
	fi->fd = fd;
	fi->ofs = ofs;
	fi->read_bytes = read_bytes;
	fi->zero_bytes = zero_bytes;
	fi->writable = writable;
	fi->mapid = mapid;
	return fi;
}

struct sup_page_table_entry *
allocate_page_with_file(struct thread *t, void *upage, struct file_inf *fi){
	struct sup_page_table_entry *spt_tmp;
	spt_tmp = malloc(sizeof(struct sup_page_table_entry));
	uint8_t *addr=convert_to_pg(upage);
	if (spt_tmp == NULL){
		printf("yyy\n");
		return NULL;
	}
	spt_tmp->owner = t;
	spt_tmp->user_vaddr = addr;
	spt_tmp->writable = fi->writable;
	spt_tmp->dirty = false;
	spt_tmp->swap_index = -1;
	spt_tmp->file_inf = fi;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

/*
 * Make new supplementary page table entry for page containing virtual address addr 
 */
struct sup_page_table_entry *
allocate_page (struct thread *t, void *upage, bool writable){
    ASSERT(is_user_vaddr(upage));//page not in virtual user address
    uint8_t *addr=convert_to_pg(upage);
    struct sup_page_table_entry *spt_tmp;
    //initializing
    spt_tmp=malloc(sizeof(struct sup_page_table_entry));
    if (spt_tmp == NULL){
    	ASSERT(0);
	}
	spt_tmp->owner = t;
    spt_tmp->user_vaddr = addr;
    spt_tmp->writable=writable;
    spt_tmp->dirty=false;
    spt_tmp->swap_index = -1;
    spt_tmp->file_inf = NULL;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

//find page with user virtual page address
struct sup_page_table_entry *find_page(struct thread *t, uint8_t *upage){
	struct list *spt = &t->spt;
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	for(le = list_begin(spt);le != list_end(spt);le = list_next(le)){
		spte = list_entry(le, struct sup_page_table_entry, elem);
		if (spte->user_vaddr == upage){
			return spte;
		}
	}
	return NULL;
}

/*
 * change spte dirty to true
 */
void spte_set_dirty(struct sup_page_table_entry *spte, bool dirty){
    spte->dirty = dirty;
}

bool spte_get_dirty(struct sup_page_table_entry *spte){
	if (spte->dirty){
		return true;
	}
	if (pagedir_get_page(spte->owner->pagedir,spte->user_vaddr) != NULL){
		spte->dirty = pagedir_is_dirty(spte->owner->pagedir, spte->user_vaddr);
		return spte->dirty;
	}
	return false;
}

/*
 * Destroy supplementary page table entry in address spte
 */
void destroy_page_entry (struct sup_page_table_entry *spte){
	struct thread *t = spte->owner;
	//if file is mapped we have to over-write it
	uint8_t *frame = pagedir_get_page (t->pagedir, spte->user_vaddr);
	if (spte->file_inf != NULL){
		// function checks condition and write back file if needed
		if (frame != NULL){
			spte_write_file(spte,frame);
		}
		free(spte->file_inf);
	}
	//if vaddr is mapped by page table, we have to free frame
	uint8_t *pd = t->pagedir;
	if (frame != NULL){
		free_frame(frame);
		pagedir_clear_page (pd, spte->user_vaddr);
	}
	//if page is in swap table we have to free resources for swap table
	if (spte->swap_index != -1){
		swap_in(spte->swap_index, NULL);
	}
    free(spte);
}

/*
 * Destroy supplementary page table entry of page in virtual address addr
 */
void destroy_page_addr(void *addr){
    addr=convert_to_pg(addr);
    struct sup_page_table_entry *sup_tmp = find_page(thread_current(), addr);
    destroy_page_entry(sup_tmp);
}

void destroy_page_table(struct list *spt){
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	while (!list_empty (spt))
     {
        struct list_elem *le = list_pop_front (spt);
		spte = list_entry(le, struct sup_page_table_entry, elem);
		destroy_page_entry(spte);
     }
}
