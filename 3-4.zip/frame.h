#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <list.h>
#include "threads/thread.h"

struct frame_table_entry
{
	uint32_t* frame;
	struct sup_page_table_entry* spte;
	struct list_elem elem;
};

void frame_init (void);
bool allocate_frame (void *frame, struct sup_page_table_entry *spte);
void free_frame(void *kpage);
bool decrease_priority(struct frame_table_entry *fte);
void *evict(void);
void destroy_fte(struct frame_table_entry *fte);


#endif /* vm/frame.h */
