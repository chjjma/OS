#include "vm/frame.h"
#include "threads/malloc.h"
#include<list.h>
#include "threads/palloc.h"
#include "threads/synch.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "userprog/syscall.h"

static struct list frame_table;
static struct lock ft_lock;
static int initialize = 0;
/*
 * Initialize frame table
 */
void 
frame_init (void)
{
	list_init(&frame_table);
	lock_init(&ft_lock);
}

/* 
 * Make a new frame table entry for addr.
 */
bool
allocate_frame (void *frame, struct sup_page_table_entry *spte)
{
	if (initialize == 0){
		frame_init();
		initialize = 1;
	}
	struct frame_table_entry *fte = (struct frame_table_entry *)malloc(sizeof(struct frame_table_entry));
	if (fte == NULL){
		ASSERT(0);
		return false;
	}
	fte->spte = spte;
	fte->frame = frame;
	lock_acquire(&ft_lock);
	list_push_back(&frame_table, &fte->elem);
	lock_release(&ft_lock);
	return true;
}

void
free_frame(void *kpage){
	struct frame_table_entry *fte;
	struct list_elem le;
	lock_acquire(&ft_lock);
	for (le = list_begin(frame_table); le!= list_end(frame_table); le=list_next(le)){
		fte = list_entry(le, struct frame_table_entry, elem);
		if (fte->frame == kpage){
			destroy_fte(fte);
	    	palloc_free_page(kpage);
	    	break;
	    }
	}
	lock_release(&ft_lock);
}

bool decrease_priority(struct frame_table_entry *fte){
	struct sup_page_table_entry *spte = fte->spte;
	uint32_t *pd = spte->owner->pd;
	/*if (pagedir_is_dirty(pd, spte->user_vaddr)){
		fte->spte->dirty = true;
		pagedir_set_dirty(pd, spte->user_vaddr,false);
		return true;
	}*/ 
	ASSERT(pd);
	if (pagedir_is_accessed(pd, spte->user_vaddr)){
		pagedir_set_accessed(pd,spte->user_vaddr,false);
		return true;
	}
	return false;
}

// eviction with second chance algorithm
// evict to swap table
void * 
evict(void){
	void *p;
	lock_acquire(&ft_lock);
	struct frame_table_entry *fte;
	struct list_elem *le;
	while(true){
		le = list_pop_front (&frame_table);
		fte = list_entry(le, struct frame_table_entry, elem);
		if (!decrease_priority(fte)){
			break;
		}
		list_push_back(&frame_table,&le);
	}
	// if page is not dirty, we can read back from file system
	uint8_t *empty_frame;
	if (use_swap(fte->spte)){
		swap_out(fte->frame, fte->spte);
		empty_frame = fte->frame;
		memset(empty_frame,0,PGSIZE);
		destroy_fte(fte);
		lock release(&ft_lock);
		return empty_frame;
	}
	bool ret;
	spte_write_file(fte->spte, fte->frame);
	empty_frame = fte->frame;
	memset(empty_frame,0,PGSIZE);
	destroy_fte(fte);
	lock_release(&ft_lock);
	return empty_frame;
}

//free frame
void destroy_fte(struct frame_table_entry fte){
	list_remove(fte->elem);
	free(fte);
	return;
}
