#include "vm/swap.h"
#include "vm/page.h"
#include "devices/disk.h"
#include "threads/synch.h"
#include <bitmap.h>

/* The swap device */
static struct disk *swap_device;

/* Tracks in-use and free swap slots */
static struct bitmap *swap_table;

/* Protects swap_table */
static struct lock swap_lock;

/* 
 * Initialize swap_device, swap_table, and swap_lock.
 */

static int swapsize; 

void 
swap_init (void)
{
	static int init = 0;
	if (init ==1){
		return;
	}
  swap_device = disk_get(1,1);
  swapsize = DISK_SECTOR_SIZE*disk_size(swap_device)/PGSIZE;
  swap_table = bitmap_create(swapsize);
  lock_init(&swap_lock);
  init = 1;
}

/*
 * Reclaim a frame from swap device.
 * 1. Check that the page has been already evicted. 
 * 2. You will want to evict an already existing frame
 * to make space to read from the disk to cache. 
 * 3. Re-link the new frame with the corresponding supplementary
 * page table entry. 
 * 4. Do NOT create a new supplementray page table entry. Use the 
 * already existing one. 
 * 5. Use helper function read_from_disk in order to read the contents
 * of the disk into the frame. 
 */ 
bool 
swap_in (int index, uint8_t *frame)
{
  if (frame == NULL){
    bitmap_set (swap_table, index, false);
  	//printf("swap in fail\n");
  	return false;
  }
  lock_acquire(&swap_lock);
  ASSERT(index>=0);
  if(bitmap_test(swap_table,index) == false) {
  	//printf("swap in fail\n");
    lock_release(&swap_lock);
	return false;	
  }
  lock_release(&swap_lock);
  read_from_disk(frame, index);
  lock_acquire(&swap_lock);
  bitmap_set (swap_table, index, false);
  //printf("swap in %d\n", index);
  lock_release(&swap_lock);
  return true;
}

/* 
 * Evict a frame to swap device. 
 * 1. Choose the frame you want to evict. 
 * (Ex. Least Recently Used policy -> Compare the timestamps when each 
 * frame is last accessed)
 * 2. Evict the frame. Unlink the frame from the supplementray page table entry
 * Remove the frame from the frame table after freeing the frame with
 * pagedir_clear_page. 
 * 3. Do NOT delete the supplementary page table entry. The process
 * should have the illusion that they still have the page allocated to
 * them. 
 * 4. Find a free block to write you data. Use swap table to get track
 * of in-use and free swap slots.
 */
bool
swap_out (uint8_t *frame, struct sup_page_table_entry *spte)
{
  if(frame==NULL) return false;
  lock_acquire(&swap_lock);
  int i;
  for(i=0;i<swapsize;i++){
  	if(bitmap_test(swap_table,i)==false) break;
  }
  if (i==swapsize) {
  	ASSERT(0);
  	//PANIC();
  }
  bitmap_set (swap_table, i, true);
  write_to_disk(frame,i);
  //printf("swap out %d\n", i);
  spte->swap_index=i;
  lock_release(&swap_lock);
  return true;
}

/* 
 * Read data from swap device to frame. 
 * Look at device/disk.c
 */
void read_from_disk (uint8_t *frame, int index)
{
  int i, size=PGSIZE/DISK_SECTOR_SIZE;
  for(i=0;i<size;i++){
        disk_read(swap_device, size*index+i, frame+i*DISK_SECTOR_SIZE);
  }
}

/* Write data to swap device from frame */
void write_to_disk (uint8_t *frame, int index)
{
  int i, size=PGSIZE/DISK_SECTOR_SIZE;
  for(i=0;i<size;i++){
        disk_write(swap_device, size*index+i, frame+i*DISK_SECTOR_SIZE);
  }
}
