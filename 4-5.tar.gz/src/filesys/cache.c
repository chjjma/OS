#include "filesys/cache.h"
#include <list.h>
#include <debug.h>
#include <string.h>
#include "filesys/filesys.h"
#include "devices/timer.h"
#include "threads/synch.h"
#include "threads/malloc.h"
#include "threads/thread.h"

/* The Cache */
struct cache buffer_cache[64];

/*write index of current cache*/
static int wi;

/* eviction index of current cache */
static int di;

/*protects whole cache buffer*/
static struct lock cache_lock;

static struct lock tmp;

static struct semaphore sema;
/* eviction needed?*/
static bool full; 

static bool quit;
//initializing cache
void
cache_init (void){
    int i;
    for(i=0;i<64;i++){
        buffer_cache[i].data=malloc(DISK_SECTOR_SIZE);
	buffer_cache[i].dirty=false;
	buffer_cache[i].used=false;
	buffer_cache[i].sector=-1;
	lock_init(&buffer_cache[i].cache_lock);
    }
    di=0;
    wi=0;
    quit=false;
    lock_init(&cache_lock);
    lock_init(&tmp);
    sema_init(&sema,0);
    full=false;
    thread_create("cache_refresh", PRI_MAX, cache_refresh, NULL);
}

void
cache_evict(void){
    lock_acquire(&buffer_cache[di].cache_lock);
    cache_delete();
    lock_release(&tmp);
}

int
cache_insert(disk_sector_t sector){
    ASSERT(sector!=-1);
    int t;
	for(t=0;t<64;t++)
	    if(buffer_cache[t].sector==sector){
		lock_acquire(&buffer_cache[t].cache_lock);
		lock_release(&cache_lock);
		return t;
	    }
	if(full){
	    lock_acquire(&tmp);
	    cache_evict();
	}
	else lock_acquire(&buffer_cache[wi].cache_lock);
	lock_acquire(&tmp);
	lock_release(&tmp);
	disk_read(filesys_disk, sector, buffer_cache[wi].data);
	t=wi;
	buffer_cache[wi].used=true;
	buffer_cache[wi].dirty=false;
	buffer_cache[wi].sector=sector;
	wi+=1;
	wi%=64;
	if(di==wi)full=true;
	lock_release(&cache_lock);
    return t;
}

void
cache_delete(void){
    int i=di;
    ASSERT(i!=64);
    if(buffer_cache[i].dirty)
	disk_write(filesys_disk, buffer_cache[i].sector, buffer_cache[i].data);
	full=false;
	buffer_cache[i].dirty=false;
	buffer_cache[i].used=false;
	buffer_cache[i].sector=-1;
	di=i+1;
	di%=64;
}

void
cache_done(void){
    quit=true;
    lock_acquire(&cache_lock);
    int i;
    //while(sema.value!=0)timer_sleep(1000);
    for(i=0;i<64;i++){
	//lock_acquire(&cache_lock);
	lock_acquire(&buffer_cache[i].cache_lock);
	if(buffer_cache[i].dirty)
		if(buffer_cache[i].used) 
		disk_write(filesys_disk, buffer_cache[i].sector, buffer_cache[i].data);
	buffer_cache[i].dirty=false;
	buffer_cache[i].used=false;
	free(buffer_cache[i].data);
//	lock_release(&buffer_cache[i].cache_lock);
	//lock_release(&cache_lock);
    }
    wi=0;
    di=0;
    full=false;
//    lock_release(&cache_lock);
}

void
cache_refresh(void){
    int i;
    bool t=false;
    long long int st=0;
    for(;;){
	if(st==2147483647)
	    timer_sleep(1);
	t=true;
	if(quit==true)break;
	//lock_acquire(&cache_lock);
    	    for(i=0;i<64;i++){
		if(!lock_try_acquire(&buffer_cache[i].cache_lock))continue;
		if(quit==true){
		    lock_release(&buffer_cache[i].cache_lock);
		    break;
		}
		if(buffer_cache[i].dirty&&buffer_cache[i].used){
	    	    disk_write(filesys_disk, buffer_cache[i].sector, buffer_cache[i].data);
	    	    buffer_cache[i].dirty=false;
		    t=false;
		}
		lock_release(&buffer_cache[i].cache_lock);
	    }
	if(t==true)st+=1;
	else st=0;
	//lock_release(&cache_lock);
	if(quit==true)break;
    }
}

void
cache_read(disk_sector_t sector, uint8_t *buffer, off_t size, off_t offset){
    //printf("cache read:in sector %d to buffer with size %d in offset %d\n",sector,size,offset);
    lock_acquire(&cache_lock);
    int i;
    for(i=0;i<64;i++)
	if(buffer_cache[i].sector==sector)break;
    if(i<64){
	lock_acquire(&buffer_cache[i].cache_lock);
	lock_release(&cache_lock);
    }
    else i=cache_insert(sector);
    memcpy(buffer, buffer_cache[i].data+offset, size);
    //printf("offset %d reading done\n", offset);
    lock_release(&buffer_cache[i].cache_lock);
}


void
cache_write(disk_sector_t sector, const uint8_t *buffer, off_t size, off_t offset){
    int i;
    //sema_up(&sema);
    lock_acquire(&cache_lock);
    for(i=0;i<64;i++)if(buffer_cache[i].sector==sector)break;
    if(i<64){
	lock_acquire(&buffer_cache[i].cache_lock);
	lock_release(&cache_lock);
    }
    else i=cache_insert(sector);	
    memcpy(buffer_cache[i].data+offset, buffer, size);
    //disk_write(filesys_disk, buffer_cache[i].sector, buffer_cache[i].data);
    buffer_cache[i].dirty=true;
    lock_release(&buffer_cache[i].cache_lock);
    //sema_down(&sema);
}


