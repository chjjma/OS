#include "vm/page.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "threads/vaddr.h"
#include "threads/init.h"
#include "threads/thread.h"
#include <list.h>
/*
 * Initialize supplementary page table for process
 */
void page_init (struct thread *t){
	list_init(&t->spt);
	lock_init(&t->sptlock);
}


struct file_inf *allocate_fileinf(char *fn, off_t ofs, uint32_t read_bytes, uint32_t zero_bytes, bool writable, bool mapped){
	struct file_inf *fi = malloc(sizeof(struct file_int));
	if (t == NULL){
		ASSERT(0);
	}
	// header file not included
	strcpy(fi->file_name, fn);
	fi->ofs = ofs;
	fi->read_bytes = read_bytes;
	fi->zero_bytes = zero_bytes;
	fi->writable = writable;
	fi->mapped = mapped;
	return fi;
}

struct sup_page_table_entry *
allocate_page_with_file(struct thread *t, void *upage, struct file_inf *fi){
	spt_tmp = malloc(size_t(struct sup_page_table_entry));
	addr=convert_to_pg(upage);
	if (stp_tmp == NULL){
		ASSERT(0);
	}
	spt_tmp->owner = t;
	spt_tmp->user_vaddr = addr;
	spt_tmp->loc = 3;
	spt_tmp->writable = fi->writable;
	spt_tmp->dirty = false;
	spt_tmp->swap_index = -1;
	spt_tmp->file_inf = fi;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

/*
 * Make new supplementary page table entry for page containing virtual address addr 
 */
struct sup_page_table_entry *
allocate_page (struct thread *t, void *upage, bool writable){
    ASSERT(is_user_vaddr(upage));//page not in virtual user address
    addr=convert_to_pg(upage);
    struct sup_page_table_entry *spt_tmp;
    //initializing
    spt_tmp=malloc(size_t(struct sup_page_table_entry));
    if (spt_tmp == NULL){
    	ASSERT(0);
	}
	spt_tmp->owner = t;
    spt_tmp->user_vaddr = addr;
    spt_tmp->loc=1;
    spt_tmp->writable=writable;
    spt_tmp->dirty=false;
    spt_tmp->swap_index = -1;
    spt-tmp->file_inf = NULL;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

//find page with user virtual page address
struct sup_page_table_entry *find_page(struct thread *t, uint8_t *upage){
	struct list *spt = &t->spt;
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	for(le = list_begin(spt);le != list_end(spt);le = list_next(le)){
		spte = list_entry(le, struct sup_page_table_entry, elem);
		if (spte->user_vaddr == upage){
			return spte;
		}
	}
	return NULL;
}

/*
 * location of page of spte changed to loc (>0:in frame, =0:in swap, <0:in disk)
*/
void change_spte_loc(struct sup_page_table_entry *spte, short loc){
    spte.loc=loc;
}

/*
 * change spte dirty to true
 */
void spte_set_dirty(struct sup_page_table_entry *spte, bool dirty){
    spte.dirty = dirty;
}

bool spte_get_dirty(struct sup_page_table_entry *spte){
	if (spte->dirty){
		return true;
	}
	if (pagedir_get_page(spte->owner->pagedir,spte->user_vaddr) != NULL){
		spte->dirty = pagedir_is_dirty(spte->owner->pagedir, spte->user_vaddr);
		return spte->dirty;
	}
	return false;
}

/*
 * Destroy supplementary page table entry in address spte
 */
void destroy_page_entry (struct sup_page_table_entry *spte){
	struct thread *t = spte.owner;
	lock_acquire(&t->sptlock);
	list_remove(&spte->elem);
	lock_release(&t->sptlock);
	//if file is mapped we have to over-write it
	if (spte->file_inf != NULL){
		free(spte->file_inf);
	}
	//if vaddr is mapped by page table, we have to free resource
	//and unmap the frame from page table
	
	//if page is in swap table we have to free resources for swap table
    free(spte);
}

/*
 * Destroy supplementary page table entry of page in virtual address addr
 */
void destroy_page_addr (void *addr){
    addr=convert_to_pg(addr);
    struct sup_page_table_entry *sup_addr=find_page(addr);
    destroy_page_entry(sup_tmp);
}

void destroy_page_table(struct list *spt){
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	//lock_acquire(&spte->owner->sptlock);
	for (le = list_begin(spt); le!= list_end; ){
		spte = list_entry(le,struct sup_page_table_entry, elem);
		le = list_next(le);
		destroy_page_entry(spte);
	}
	//lock_release(&spte->owner->sptlock);
}
