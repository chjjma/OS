#ifndef VM_PAGE_H
#define VM_PAGE_H

#include "threads/vaddr.h"
#include "filesys/filesys.h"

struct sup_page_table_entry 
{
	int swap_index;
	struct thread *owner;
	uint32_t* user_vaddr;
	struct list_elem elem;
	short loc;    //loc=0:all-zero page, loc=1:frame, loc=2:swap, loc=3:disk
	struct file_inf *file_inf;
	bool dirty;
	bool writable;
};

struct file_inf{
	char file_name[64];
	off_t ofs;
	uint32_t read_bytes;
	uint32_t zero_bytes;
	bool writable;
	bool mapped;
};

void page_init (struct thread *t);
bool use_swap (struct sup_page_table_entry *spte);
bool spte_read_file(struct sup_page_table_entry *spte, uint8_t *frame);
bool spte_write_file(struct sup_page_table_entry *spe, uint8_t *frame);
bool set_frame(struct sup_page_table_entry *spte, uint8_t *frame);

struct file_inf *allocate_fileinf(char *fn, off_t ofs, uint32_t read_bytes, uint32_t zero_bytes, bool writable, bool mapped);
struct sup_page_table_entry *allocate_page_with_file(struct thread *t, void *upage, struct file_inf *fi);
struct sup_page_table_entry *allocate_page (void *frame, void *upage, bool writable);
struct sup_page_table_entry *find_page(struct thread *t, uint8_t *upage);

void spte_set_dirty(struct sup_page_table_entry *spte, bool dirty);
bool spte_get_dirty(struct sup_page_table_entry *spte);

void destroy_page_entry(struct sup_page_table_entry *spte);
void destroy_page_addr(void *addr);
void destroy_page_table(struct list *spt);

static inline unsigned convert_to_pg (const void *va){
  return ((uintptr_t) (va) >> PGBITS) << PGBITS;
}

#endif /* vm/page.h */
