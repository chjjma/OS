#include "vm/page.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "threads/vaddr.h"
#include "threads/init.h"
#include "threads/thread.h"
#include <string.h>
#include <list.h>
/*
 * Initialize supplementary page table for process
 */
void page_init (struct thread *t){
	list_init(&t->spt);
	lock_init(&t->sptlock);
}

bool use_swap(struct sup_page_table_entry *spte){
	if (spte->file_inf == NULL){
		return true;
	}
	if (spte->dirty == false){
		return true;
	}
	return false;
}

bool spte_read_file(struct sup_page_table_entry *spte, uint8_t *frame){
	ASSERT(spte->file_inf != NULL);
	struct file_inf *fi = spte->file_inf;
	struct file *file;
	if (fd != -1){
		file = get_file(fd);
	}
	else{
		file = file_open(spte->owner->process_name);
	}
    file_seek (file, fi->ofs);
	/* Load this page. */
	if (file_read (file, frame, fi->read_bytes) != (int) fi->read_bytes)
	{
		return false;
	}
	memset (frame + fi->read_bytes, 0, fi->zero_bytes);
	if (fd ==-1){
		file_close(file);
	}
	return true;
}

bool spte_write_file(struct sup_page_table_entry *spe, uint8_t *frame){
	ASSERT(spte->file_inf != NULL);
	struct file_inf *fi = spte->file_inf;
	struct file *file;
	if (fd == -1){
		return false;
	}
	file = get_file(fd);
	int old_ofs = file_tell(file);
    file_seek (file, fi->ofs);
	/* Load this page. */
	if (file_write (file, frame, fi->read_bytes) != (int) fi->read_bytes)
	{
		file_seek (file, old_ofs);
		return false;
	}
	file_seek (file, old_ofs);
	return true;
}


bool set_frame(struct sup_page_table_entry *spte, uint8_t *frame){
	ASSERT(spte!= NULL);
	ASSERT(frame!= NULL);
	struct thread *t = spte->owner;
	if (pagedir_get_page (t->pagedir, spte->user_vaddr) != NULL) {
      	return false;
    }
    if (!pagedir_set_page (t->pagedir, spte->user_vaddr, frame, writable)){
    	return false;
	}
	frame_allocate(frame, spte);
    return true;
}

struct file_inf *allocate_fileinf(int fd, off_t ofs, uint32_t read_bytes, uint32_t zero_bytes, bool writable, int mapid){
	struct file_inf *fi = malloc(sizeof(struct file_int));
	if (fi == NULL){
		return NULL;
	}
	// header file not included
	fi->fd = fd;
	fi->ofs = ofs;
	fi->read_bytes = read_bytes;
	fi->zero_bytes = zero_bytes;
	fi->writable = writable;
	fi->mapid = mapid;
	return fi;
}

struct sup_page_table_entry *
allocate_page_with_file(struct thread *t, void *upage, struct file_inf *fi){
	spt_tmp = malloc(size_t(struct sup_page_table_entry));
	addr=convert_to_pg(upage);
	if (stp_tmp == NULL){
		return NULL;
	}
	spt_tmp->owner = t;
	spt_tmp->user_vaddr = addr;
	spt_tmp->writable = fi->writable;
	spt_tmp->dirty = false;
	spt_tmp->swap_index = -1;
	spt_tmp->file_inf = fi;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

/*
 * Make new supplementary page table entry for page containing virtual address addr 
 */
struct sup_page_table_entry *
allocate_page (struct thread *t, void *upage, bool writable){
    ASSERT(is_user_vaddr(upage));//page not in virtual user address
    addr=convert_to_pg(upage);
    struct sup_page_table_entry *spt_tmp;
    //initializing
    spt_tmp=malloc(size_t(struct sup_page_table_entry));
    if (spt_tmp == NULL){
    	ASSERT(0);
	}
	spt_tmp->owner = t;
    spt_tmp->user_vaddr = addr;
    spt_tmp->writable=writable;
    spt_tmp->dirty=false;
    spt_tmp->swap_index = -1;
    spt-tmp->file_inf = NULL;
    //adds new entry into table
    lock_acquire(&t->sptlock);
    list_push_back(&t->spt,&spt_tmp->elem);
    lock_release(&t->sptlock);
    return spt_tmp;
}

//find page with user virtual page address
struct sup_page_table_entry *find_page(struct thread *t, uint8_t *upage){
	struct list *spt = &t->spt;
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	for(le = list_begin(spt);le != list_end(spt);le = list_next(le)){
		spte = list_entry(le, struct sup_page_table_entry, elem);
		if (spte->user_vaddr == upage){
			return spte;
		}
	}
	return NULL;
}

/*
 * change spte dirty to true
 */
void spte_set_dirty(struct sup_page_table_entry *spte, bool dirty){
    spte.dirty = dirty;
}

bool spte_get_dirty(struct sup_page_table_entry *spte){
	if (spte->dirty){
		return true;
	}
	if (pagedir_get_page(spte->owner->pagedir,spte->user_vaddr) != NULL){
		spte->dirty = pagedir_is_dirty(spte->owner->pagedir, spte->user_vaddr);
		return spte->dirty;
	}
	return false;
}

/*
 * Destroy supplementary page table entry in address spte
 */
void destroy_page_entry (struct sup_page_table_entry *spte){
	struct thread *t = spte.owner;
	lock_acquire(&t->sptlock);
	list_remove(&spte->elem);
	lock_release(&t->sptlock);
	//if file is mapped we have to over-write it
	uint8_t *frame = pagedir_get_page (t->pagedir, spte->user_vaddr);
	if (spte->file_inf != NULL){
		// function checks condition and write back file if needed
		if (frame != NULL){
			spte_file_write(spte,frame);
		}
		free(spte->file_inf);
	}
	//if vaddr is mapped by page table, we have to free frame
	uint8_t *pd = t->pagedir;
	if (frame != NULL){
		free_frame(frame);
		pagedir_clear_page (pd, spte->user_vaddr);
	}
	//and unmap the frame from page table
	if (spte->swap_index != -1){
		swap_in(spte->swap_index, NULL);
	}
	//if page is in swap table we have to free resources for swap table
    free(spte);
}

/*
 * Destroy supplementary page table entry of page in virtual address addr
 */
void destroy_page_addr(void *addr){
    addr=convert_to_pg(addr);
    struct sup_page_table_entry *sup_addr=find_page(addr);
    destroy_page_entry(sup_tmp);
}

void destroy_page_table(struct list *spt){
	struct list_elem *le;
	struct sup_page_table_entry *spte;
	//lock_acquire(&spte->owner->sptlock);
	for (le = list_begin(spt); le!= list_end; ){
		spte = list_entry(le,struct sup_page_table_entry, elem);
		le = list_next(le);
		destroy_page_entry(spte);
	}
	//lock_release(&spte->owner->sptlock);
}
