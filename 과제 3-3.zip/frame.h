#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <list.h>
#include "threads/thread.h"

struct frame_table_entry
{
	uint32_t* frame;
	struct sup_page_table_entry* spte;
	struct list_elem elem;
};

void frame_init (void);
bool allocate_frame (void *frame, void *upage, struct thread *t);

#endif /* vm/frame.h */
